from flask import Flask,render_template, request
from sklearn.externals import joblib
import pandas as pd
import numpy as np
app = Flask(__name__)
#@app.route('/test')
#def test():
#    return "Flask is being used by sachin"
# Load model_prediction

@app.route('/')
def home():
    return render_template('home.html')

@app.route("/predict", methods=['GET','POST'])
def predict():
    if request.method == 'POST':
        try:
            # NewYork = float(request.form['NewYork'])
            Sex_male = float(request.form['Sex_male'])
            age = float(request.form['age'])
            cigsPerDay = float(request.form['cigsPerDay'])
            totChol = float(request.form['totChol'])
            sysBP = float(request.form['sysBP'])
            
            
            glucose = float(request.form['glucose'])
            pred_args = [Sex_male,age,cigsPerDay,totChol,sysBP,glucose]
            pred_args_arr = np.array(pred_args)
            pred_args_arr = pred_args_arr.reshape(1,-1)
            mul_reg = open("heart2.pkl","rb")
            ml_model = joblib.load(mul_reg)
            model_prediction = ml_model.predict(pred_args_arr)
            

        except valueError:
            return "Check values again"
    
    return render_template("predict.html", prediction = model_prediction )
if __name__ == "__main__":
    app.run()
