package com.example.diseasepredictor.ui.slideshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.diseasepredictor.R;

public class SlideshowFragment extends Fragment implements AdapterView.OnItemSelectedListener {


    private SlideshowViewModel slideshowViewModel;
      Spinner spinner;
      float x,y,z,r,a,b,c,j;
      EditText editText;
      String tar;
      float tarN;
      Button button;
      TextView textView;
      TextView textView1;
      TextView textView2;
      TextView textView3;
    static final String[] brands = {"Marl Boro","State Express 555","Surya"};
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(SlideshowViewModel.class);
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);


        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        spinner = (Spinner) view.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, brands);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
        editText = (EditText)view.findViewById(R.id.day);
        textView = (TextView)view.findViewById(R.id.tarlevel);
        textView1=(TextView)view.findViewById(R.id.nicotine);
        textView2 = (TextView)view.findViewById(R.id.carbon);
        textView3 =(TextView)view.findViewById(R.id.money);

        button = (Button)view.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar=editText.getText().toString();
                tarN=Integer.parseInt(tar);
                a=tarN*x;
                b=tarN*y;
                c=tarN*z;
                j=r*tarN;
                textView.setText(Float.toString(a)+" mg");
                textView1.setText(Float.toString(b)+" mg");
                textView2.setText(Float.toString(c)+" mg");

                textView3.setText(Float.toString(j)+" Rupees");


            }
        });



    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


        switch(i)
        {
            case 0: {x=(float)12.9;
                y=(float)1.3;
                z=(float)12.9;
                r=(float)10; }
            break;
            case 1:  x=(float)13.5;
                y=(float)1.19;
                z=(float)13.5;
                 r=(float)15;
                break;
            case 2: x=(float)18.2;
                y=(float)1.31;
                z=(float)13.7;
                r=(float)20;
                break;

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}