import pandas as pd
import numpy as np
import scipy.stats as st
import statsmodels.api as sm
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn import utils
import matplotlib.mlab as mlab
import scipy.optimize as opt

df=pd.read_csv('C:/Users/Sehej Bakshi/Desktop/New folder/lung_cancer.csv')
print(df.head())


from statsmodels.tools import add_constant as add_constant
df_constant=add_constant(df)
print(df_constant.head())


st.chisqprob = lambda chisq, df: st.chi2.sf(chisq, df)
cols=df_constant.columns[:-1]
model = sm.Logit(df.Probability, df_constant[cols])
result=model.fit()
print(result.summary())

def back_feature_elem(data_frame, dep_var, col_list):
    while len(col_list)>0:
        model=sm.Logit(dep_var, data_frame[col_list])
        result=model.fit(disp=0)
        largest_pvalue=round(result.pvalues, 3).nlargest(1)
        if largest_pvalue[0]<(0.05):
            return result
            break
        else:
            col_list=col_list.drop(largest_pvalue.index)

result = back_feature_elem(df_constant, df.Probability, cols)


params=np.exp(result.params)
conf=np.exp(result.conf_int())
conf['OR']=params
pvalue=round(result.pvalues, 3)
conf['pvalue']=pvalue
conf.columns=['CI 95%(2.5%)', 'CI 95%(97.5%)', 'Odds Ratio', 'pvalue']
print(conf)



import sklearn
new_features=df[['cigsPerDay', 'Age', 'BMI', 'Glucose', 'Age_of_initiation', 'Probability']]
x=new_features.iloc[:, :-1]
y=new_features.iloc[:, -1]
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=4)


##lab_enc=preprocessing.LabelEncoder()
##ytrain_encoded=lab_enc.fit_transform(y_train)

from sklearn.linear_model import LinearRegression
LR=LinearRegression()
LR.fit(x_train, y_train)

x1=18
x2=48
x3=31.62
x4=104.883
x5=27

x_testi=np.array([[x1, x2, x3, x4, x5]])



y_pred=LR.predict(x_testi)
if y_pred>1.00:
    y_pred=0.99
##print('Accuracy of model:', sklearn.metrics.explained_variance_score(y_test, y_pred))
print('Your chances of getting lung cancer is:', y_pred)
##ypred_prob=LR.predict_proba(x_test)[:,1:]
##print('Probability of getting a heart disease:', ypred_prob)
##
